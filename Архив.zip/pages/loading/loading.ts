import {Component} from '@angular/core';

@Component({
	templateUrl: 'loading.html'
})

export class Loading {
}
